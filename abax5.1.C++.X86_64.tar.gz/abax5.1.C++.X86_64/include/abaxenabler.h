///////////////////////////////////////////////////////////////////////////////////////
//
//  Bigdata Enabler
//
//  Exeray Inc, All Rights Reserved   www.exeray.com
//
//  THIS SOFTWARE IS PROVIDED BY EXERAY INC "AS IS" AND ANY EXPRESS OR IMPLIED 
//  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
//  MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO 
//  EVENT SHALL EXERAY INC BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
//  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT 
//  OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
//  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
//  STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
//  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
///////////////////////////////////////////////////////////////////////////////////////

#ifndef _abax_enabler_h_
#define _abax_enabler_h_

#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <sys/types.h>
#include <limits.h>
#include <ctype.h>
#include <string>


/////////////// Enum Types //////////////////
enum AbaxDestroyAction { ABAX_NOOP=0, ABAX_FREE = 10 };
enum { ABAXITERALL=0, ABAXITERSTART=10, ABAXITERCOUNT=20, ABAXITERSTARTCOUNT=30, ABAXITERSTARTEND=40 };
enum AbaxBegin { ABAXNO=0, ABAXYES=1 };
enum AbaxStepAction { ABAX_NOMOVE=0, ABAX_NEXT=1 };
enum AbaxGraphType { ABAX_UNDIRECTED=0, ABAX_DIRECTED=1 };
enum AbaxLinkType { ABAX_DOUBLELINK=0, ABAX_INLINK=1, ABAX_OUTLINK=2 };
enum AbaxQueueType { ABAX_MINQUEUE=1, ABAX_MAXQUEUE=2 };

template <class K> class AbaxFlatSet;
template <class K, class V> class AbaxFlatMap;

typedef long abaxint;
typedef std::string AbaxDataString;
class abaxstream;

///////////////////// Mutex and Locks ////////////////////////////////////
class AbaxReadWriteLock 
{
  protected:
    long 				_numReaders, _numWriters, _numWritersWaiting;
    pthread_mutex_t 	_mutexObject;
    pthread_cond_t  	_readerCond;
    pthread_cond_t  	_writeCond;

  public:

    AbaxReadWriteLock()
      : _numReaders(0), _numWriters(0), _numWritersWaiting(0)
    {
		pthread_mutex_init ( &_mutexObject, NULL);
		pthread_cond_init ( &_readerCond, NULL);
		pthread_cond_init ( &_writeCond, NULL);
	}

    ~AbaxReadWriteLock()
    {
        pthread_mutex_destroy(&_mutexObject);
        pthread_cond_destroy(&_readerCond);
        pthread_cond_destroy(&_writeCond);
    }

    void readLock()
    {
        pthread_mutex_lock(&_mutexObject);
        while(_numWriters>0) {
            pthread_cond_wait(&_readerCond, &_mutexObject);
        }
        ++ _numReaders;        
        pthread_mutex_unlock(&_mutexObject);
    }

    void writeLock()
    {
        pthread_mutex_lock(&_mutexObject);
        ++ _numWritersWaiting;

        while( _numReaders > 0 || _numWriters > 0 ) {
            pthread_cond_wait( &_writeCond, &_mutexObject );
        }

        -- _numWritersWaiting; 
		++ _numWriters;
        pthread_mutex_unlock(&_mutexObject);
    }

    void readUnlock()
    {
        pthread_mutex_lock(&_mutexObject);
        -- _numReaders;

        if( 0 == _numReaders && _numWritersWaiting > 0 )
            pthread_cond_signal(&_writeCond);

        pthread_mutex_unlock(&_mutexObject);
    }

    void writeUnlock()
    {
        pthread_mutex_lock(&_mutexObject);
        -- _numWriters;

        if( _numWritersWaiting > 0)
            pthread_cond_signal(&_writeCond);

        pthread_cond_broadcast(&_readerCond);
        pthread_mutex_unlock(&_mutexObject);
    }

};


/////////// Read and Write mutex for readers and writers ////////
class AbaxReadWriteMutex
{
  public:
    AbaxReadWriteMutex( AbaxReadWriteLock *_mutex );
    AbaxReadWriteMutex( AbaxReadWriteLock *_mutex, int lockType );
	void readLock();
	void writeLock();
	void readUnlock();
	void writeUnlock();
    ~AbaxReadWriteMutex( );

	static  const  int  READ_LOCK = 1;
	static  const  int  WRITE_LOCK = 2;

  protected:
	AbaxReadWriteLock  *_lock;
	int				   _type;  
};

////////////////////////// AbaxFormat ///////////////////////////////////////////
class AbaxFormat
{
	public:
		AbaxFormat() {
			len = 0;
		}

		void setKeyFormat(const char *format=NULL) {
			if ( format != NULL ) {
				parse( format );
			}
		}

		~AbaxFormat() {
			if ( len > 0 ) {
				delete [] typearr;
				delete [] lenarr;
				delete [] separr;
			}
		}

		void print()
		{
			int i;

			printf("typearr: " );
			for ( i=0; i < len; ++i)
			{
				printf("%c ", typearr[i] );
			}
			printf("\n");

			printf("lenarr: " );
			for ( i=0; i < len; ++i)
			{
				printf("%d ", lenarr[i] );
			}
			printf("\n");

			printf("separr: " );
			for ( i=0; i < len; ++i)
			{
				printf("[%c] ", separr[i] );
			}
			printf("\n");

		}

	public:
		int  len;
		char *typearr;
		int  *lenarr;
		char *separr;

	private:
		void parse( const char *format ) 
		{
			// format:  "%s,%d|%s:%3d-%10s-%d,%4d%5s%8d%12s"
			const char *p;
			const char *beg;
			int i;

			// check empty format
			len = 0;
			if ( 0 == strcmp(format, "") || 0 == strcmp(format, "%")  ) {
				return;
			}

			// get len
			p = format;
			while( *p ) {
				if ( *p == '%' ) {
					++len;
				}
				++p;
			}

			if ( len < 1 ) return;

			typearr = new char[len];
			lenarr = new int[len];
			separr = new char[len];

			p = format;
			i = 0;
			while( *p ) {
				if ( *p == '%' ) {
					++p;   // 23d  or  1s  or s  or d
					beg = p;
					while ( isdigit( *p ) ) ++p;
					// p should be sep char now

					if ( beg == p ) {
						// no length
						lenarr[i] = 0;
					} else {
						lenarr[i] = atoi(beg);  // 23d gives 23  ;  3s --> 3
					}

					// *p should be d or s, if not, exit
					if ( *p == 's' || *p == 'd' ) {
						typearr[i] = *p;
					} else {
						printf("e2414 fatal error: format [%s] is invalid\n", format );
						exit(1);
					}

					if ( *(p+1) == '%' )  // %23d%   not sep
					{
						separr[i] = '\0';
					}
					else
					{
						separr[i] = *(p+1);  // %23d,
					}
					++i;
				}
				++p;
			}

		}
};
template <class KType> int compareString( const KType &s1, const KType &s2,  const AbaxFormat &fmt );

/////////////////////////// AbaxVector /////////////////////////////////////////////
template <class Pair>
class AbaxVector
{
	public:

		AbaxVector( int initSize=256 );

		template <class P> AbaxVector( const AbaxVector<P>& other );
		AbaxVector<Pair>& operator=( const AbaxVector<Pair>& other );

		void init( int sz );
		~AbaxVector();

		inline const Pair & operator[] ( abaxint i ) const { return _arr[i]; }
		inline Pair & operator[] ( abaxint i ) { return _arr[i]; }
		inline bool exist( const Pair &pair ) { abaxint idx; return exist(pair, &idx); }
		void setNull( const Pair &pair, abaxint i );
		bool exist( const Pair &pair, abaxint *index );
		bool remove( const Pair &pair, AbaxDestroyAction action=ABAX_NOOP ); 
		bool get( Pair &pair ); 
		bool set( const Pair &pair ); 
		void destroy();
		inline void reset() {
			if ( _elements > 0 ) {
				destroy(); init(256);
			}
		}
		inline  abaxint capacity() const { return _arrlen; }
		inline  abaxint size() const { return _elements; }
		inline  abaxint last() const { return _last; }
		inline  const Pair* array() const { return (const Pair*)_arr; }
		inline bool append( const Pair &newpair ) { abaxint idx; return append(newpair, &idx); }
		bool append( const Pair &newpair, abaxint *index );
		bool insertForce( const Pair &newpair, abaxint index );
		bool insertLess( const Pair &newpair, abaxint index );
		bool setNull(); 
		void concurrent( bool flag = true );
		void print();
		void 	reAlloc();
		void 	reAllocShrink();


	protected:

		static const int _GEO  = 2;
		Pair   		*_arr;
		abaxint  	_arrlen;
		Pair   		*_newarr;
		abaxint  	_newarrlen;
		abaxint  	_elements;
		abaxint  	_last;
		AbaxReadWriteLock  *_lock;
};

// ctor
template <class Pair> 
AbaxVector<Pair>::AbaxVector( int initSize )
{
	init( initSize );
}
template <class Pair> 
void AbaxVector<Pair>::init( int initSize )
{
	_arr = new Pair[initSize];
	_arrlen = initSize;
	_elements = 0;
	_last = 0;
	_lock = NULL;

	for ( abaxint i = 0; i < _arrlen; ++i ) {
		_arr[i] = Pair::NULLVALUE;
	}
}

// copy ctor
template <class Pair>
template <class P>
AbaxVector<Pair>::AbaxVector( const AbaxVector<P>& other )
{
	_arrlen = other._arrlen;
	_elements = other._elements;
	_last = other._last;

	_arr = new Pair[_arrlen];
	for ( abaxint i = 0; i < _arrlen; ++i ) {
		_arr[i] = other._arr[i];
	}
}


// assignment operator
template <class Pair>
AbaxVector<Pair>& AbaxVector<Pair>::operator=( const AbaxVector<Pair>& other )
{
	AbaxReadWriteMutex mutex( _lock, AbaxReadWriteMutex::WRITE_LOCK );

	if ( _arr == other._arr ) {
		return *this;
	}

	if ( _arr ) {
		delete [] _arr;
	}

	_arrlen = other._arrlen;
	_elements = other._elements;
	_last = other._last;

	_arr = new Pair[_arrlen];
	for ( abaxint i = 0; i < _arrlen; ++i ) {
		_arr[i] = other._arr[i];
	}

	return *this;
}


// dtor
template <class Pair> 
void AbaxVector<Pair>::destroy( )
{
	if ( ! _arr ) {
		return;
	}

	if ( _arr ) {
		delete [] _arr; 
		_arr = NULL;
		_arrlen = 0;
		_elements = 0;
		_last = 0;
	}

	if ( _lock ) {
		delete _lock;
		_lock = NULL;
	}
}

// dtor
template <class Pair> 
AbaxVector<Pair>::~AbaxVector( )
{
	destroy();
}


template <class Pair> 
void AbaxVector<Pair>::reAlloc()
{
	abaxint i;
	_newarrlen  = _GEO*_arrlen; 

	_newarr = new Pair[_newarrlen];
	for ( i = 0; i < _arrlen; ++i) {
		_newarr[i] = _arr[i];
	}
	for ( i = _arrlen; i < _newarrlen; ++i) {
		_newarr[i] = Pair::NULLVALUE;
	}

	delete [] _arr;
	_arr = _newarr;
	_arrlen = _newarrlen;
}

template <class Pair> 
void AbaxVector<Pair>::reAllocShrink()
{
	abaxint i;

	_newarrlen  = _arrlen/_GEO; 

	_newarr = new Pair[_newarrlen];
	for ( i = 0; i < _elements; ++i) {
		_newarr[i] = _arr[i];
	}
	for ( i = _elements; i < _newarrlen; ++i) {
		_newarr[i] = Pair::NULLVALUE;
	}

	delete [] _arr;
	_arr = _newarr;
	_arrlen = _newarrlen;
}


template <class Pair> 
bool AbaxVector<Pair>::append( const Pair &newpair, abaxint *index )
{
	AbaxReadWriteMutex mutex( _lock, AbaxReadWriteMutex::WRITE_LOCK );

	if ( _elements == _arrlen ) { reAlloc(); }
	*index = _elements;
	_arr[_elements++] = newpair;
	return true;
}

template <class Pair> 
bool AbaxVector<Pair>::insertForce( const Pair &newpair, abaxint index )
{
	while ( index >= _arrlen ) { 
		reAlloc(); 
	}

	_arr[index] = newpair;
	if ( _arr[index] == Pair::NULLVALUE ) {
		++_elements;
	}

	if ( index > _last ) {
		_last = index;
	}

	return true;
}

template <class Pair> 
bool AbaxVector<Pair>::insertLess( const Pair &newpair, abaxint index )
{
	while ( index >= _arrlen ) { 
		reAlloc(); 
	}

	if ( _arr[index] == Pair::NULLVALUE ) {
		++_elements;
		_arr[index] = newpair;
	}  else {
		if ( newpair < _arr[index] ) {
			_arr[index] = newpair;
		}
	}

	if ( index > _last ) {
		_last = index;
	}

	return true;
}

// Slow, should not use this
template <class Pair> 
bool AbaxVector<Pair>::remove( const Pair &pair, AbaxDestroyAction action )
{
	AbaxReadWriteMutex mutex( _lock, AbaxReadWriteMutex::WRITE_LOCK );

	abaxint i, index;
	bool rc = exist( pair, &index );
	if ( ! rc ) return false;

	if ( action != ABAX_NOOP ) {
		_arr[index].valueDestroy( action ); 
	}

	// shift left
	for ( i = index; i <= _elements-2; ++i ) {
		_arr[i] = _arr[i+1];
	}
	-- _elements;

	if ( _arrlen >= 64 ) {
    	long loadfactor  = 100 * (long)_elements / _arrlen;
    	if (  loadfactor < 15 ) {
    		reAllocShrink();
    	}
	} 

	if ( index == _last ) {
		-- _last;
	}

	return true;
}


// scan search  slow
template <class Pair> 
bool AbaxVector<Pair>::exist( const Pair &search, abaxint *index )
{
	AbaxReadWriteMutex mutex( _lock, AbaxReadWriteMutex::READ_LOCK );

    abaxint i; 
	for ( i = 0; i < _elements; ++i ) {
		if ( _arr[i] == search ) {
			*index = i;
			return true;
		}
	}
    return 0;
}

template <class Pair> 
inline bool AbaxVector<Pair>::get( Pair &pair )
{
	AbaxReadWriteMutex mutex( _lock, AbaxReadWriteMutex::READ_LOCK );
	abaxint index;
	bool rc;
	rc = exist( pair, &index );
	if ( ! rc ) return false;

	pair.value = _arr[index].value;
	return true;
}

template <class Pair> 
inline bool AbaxVector<Pair>::set( const Pair &pair )
{
	AbaxReadWriteMutex mutex( _lock, AbaxReadWriteMutex::WRITE_LOCK );

	abaxint index;
	bool rc;

	rc = exist( pair, &index );
	if ( ! rc ) return false;

	_arr[index].value = pair.value;
	return true;
}

template <class Pair> 
void AbaxVector<Pair>::print()
{
	for ( abaxint i = 0; i < _elements; ++i ) {
		printf("i=%d   [%s]\n", i, _arr[i].key.c_str() );
	}	
}

template <class Pair> 
void AbaxVector<Pair>::setNull( const Pair &pair, abaxint i ) 
{
	if ( pair != Pair::NULLVALUE && _arr[i] == pair ) {
		_arr[i] = Pair::NULLVALUE; 
		-- _elements; 
	}
}

template <class Pair> 
bool AbaxVector<Pair>::setNull() 
{
	AbaxReadWriteMutex mutex( _lock, AbaxReadWriteMutex::WRITE_LOCK );

	bool rc = false;
	if ( _elements > 0 ) {
		for ( abaxint i = 0; i < _arrlen; ++i ) {
	    	_arr[i] = Pair::NULLVALUE;
		}	
		_elements = 0;
		_last = 0;
		rc = true;
	}
	return rc;
}

template <class Pair> 
void AbaxVector<Pair>::concurrent( bool flag ) 
{
	if ( flag ) {
		if ( ! _lock ) {
	 		_lock = new AbaxReadWriteLock();
	 	}
	} else {
		if ( _lock ) {
			delete _lock;
			_lock = NULL;
		}
	}
}


///////////////////////////// Basic Types ///////////////////////////////////////////////
/***
  Basic numerical types
***/
template <class DataType>
class AbaxNumeric 
{
    template <class DataType2 > friend abaxstream& operator<< ( abaxstream &os, const AbaxNumeric<DataType2> & d );

    public:
        static DataType randomValue( int size ) { return rand(); }  // todo

        static bool isString( ) { return false; }
		static AbaxNumeric NULLVALUE; 
        inline AbaxNumeric( ) { _data = 0; };
        inline AbaxNumeric( DataType d ) { _data = d ; }
        inline DataType value() const { return _data; }
        inline const char *addr() const { return (const char*)&_data; }
        inline const int addrlen() const { return 0; }
        long hashCode() const { 
			DataType positive = _data; if ( _data < 0 ) positive = 0 - _data;
			return ( (unsigned long)positive + ((unsigned long)positive >>1)  ) % LONG_MAX;
		}
        inline long toLong() const { return (unsigned long)_data; }
        inline void destroy( AbaxDestroyAction action ) { };
		inline AbaxDataString toString() const { char buf[16]; sprintf(buf, "%ld", _data ); return buf; }
		inline void valueDestroy( AbaxDestroyAction action ) {}
        inline AbaxNumeric&  operator= ( const AbaxNumeric &s2 ) {
            _data = s2._data;
            return *this;
        }

		inline AbaxNumeric&  copyKey( const AbaxNumeric &s2 ) {
            _data = s2._data;
            return *this;
		}

        inline int operator== ( const AbaxNumeric &s2 ) const {
            return (_data == s2._data );
        }
        inline int operator!= ( const AbaxNumeric &s2 ) const {
            return ( ! ( _data == s2._data ) );
        }

        inline AbaxNumeric& increment(  ) {
            ++ _data; return *this;
        }
        inline AbaxNumeric& decrement(  ) {
            -- _data; return *this;
        }

        inline int operator< ( const AbaxNumeric &s2 ) const {
            return (_data < s2._data );
        }
        inline int operator<= ( const AbaxNumeric &s2 ) const {
            return (_data <= s2._data );
        }
        inline int operator> ( const AbaxNumeric &s2 ) const {
            return (_data > s2._data );
        }
        inline int operator>= ( const AbaxNumeric &s2 ) const {
            return (_data >= s2._data );
        }

        inline AbaxNumeric& operator+= ( const AbaxNumeric &s2 ) {
            _data +=  s2._data;
			return *this;
        }

        inline int gt ( const AbaxNumeric &s2, const AbaxFormat &fmt ) const {
            return (_data > s2._data );
        }
        inline int ge ( const AbaxNumeric &s2, const AbaxFormat &fmt ) const {
            return (_data >= s2._data );
        }
        inline int lt ( const AbaxNumeric &s2, const AbaxFormat &fmt ) const {
            return (_data < s2._data );
        }
        inline int le ( const AbaxNumeric &s2, const AbaxFormat &fmt ) const {
            return (_data <= s2._data );
        }

    private:
        DataType _data;
};


/***
  String class
***/
class AbaxString 
{
    friend abaxstream & operator<< ( abaxstream &os, const AbaxString& );

    public:
        static AbaxDataString randomValue( int size=4);
        static bool isString( ) { return true; }
		static AbaxString NULLVALUE; 

        AbaxString( ) { };
        AbaxString( const AbaxDataString &str ) { _str = str; }
        AbaxString( const char *str ) { _str = str; }
        ~AbaxString( ) { };

        inline const AbaxDataString &value() const { return _str; }
		inline const AbaxDataString &toString()  const { return _str; }

		inline const char *addr() const { return _str.c_str(); }
		inline const char *c_str() const { return _str.c_str(); }
		inline const int addrlen() const { return _str.size(); }
		inline const int size() const { return _str.size(); }
        long hashCode() const ;
        inline void destroy( AbaxDestroyAction action ) { };
		inline void valueDestroy( AbaxDestroyAction action ) {}
        inline  AbaxString&  operator= ( const AbaxString &s2 ) {
            _str = s2._str; return *this;
        }
        inline  AbaxString&  copyKey ( const AbaxString &s2 ) {
            _str = s2._str; return *this;
        }

        inline  int operator== ( const AbaxString &s2 )  const {
            return (_str == s2._str );
        }
        inline  int operator!= ( const AbaxString &s2 )  const {
            return ( ! (_str == s2._str ) );
        }
        inline  int operator< ( const AbaxString &s2 ) const {
            return (_str < s2._str );
        }
        inline  int operator<= ( const AbaxString &s2 ) const {
            return (_str <= s2._str );
        }
        inline  int operator> ( const AbaxString &s2 ) const {
            return (_str > s2._str );
        }
        inline  int operator>= ( const AbaxString &s2 ) const {
            return (_str >= s2._str );
        }
		inline AbaxString& operator+= (const AbaxString &s ) {
			_str += s._str;
			return *this;
		}
        inline long toLong() const { return atol(_str.c_str()); }

        inline int gt ( const AbaxString &s2, const AbaxFormat &fmt ) const
        {
			if ( fmt.len>0 ) {
				return ( compareString<AbaxString>( _str, s2, fmt) > 0 ?1:0 );
			} else {
            	return ( _str > s2._str );
			}
        }
        inline int ge ( const AbaxString &s2, const AbaxFormat &fmt ) const
        {
			if ( fmt.len>0 ) {
				return ( compareString<AbaxString>( _str, s2, fmt) >= 0 ?1:0 );
			} else {
            	return ( _str >= s2._str );
			}
        }
        inline int lt ( const AbaxString &s2, const AbaxFormat &fmt ) const
        {
			if ( fmt.len>0 ) {
				return ( compareString<AbaxString>( _str, s2, fmt) < 0 ?1:0 );
			} else {
            	return ( _str < s2._str );
			}
        }
        inline int le ( const AbaxString &s2, const AbaxFormat &fmt ) const
        {
			if ( fmt.len>0 ) {
				return ( compareString<AbaxString>( _str, s2, fmt) <= 0 ?1:0 );
			} else {
            	return ( _str <= s2._str );
			}
        }


    private:
        AbaxDataString _str;
};


/***
  A memory buffer type
***/
class AbaxBuffer 
{
    friend abaxstream & operator<< ( abaxstream &os, const AbaxBuffer& );

    public:
        AbaxBuffer( ) {  _ptr = NULL; };
        static bool isString( ) { return false; }
		static AbaxBuffer NULLVALUE; 

         ~AbaxBuffer( ) {  };
        AbaxBuffer( void *ptr ) { _ptr = ptr; }
        inline void *value() const { return _ptr; }
        inline const char *addr() const { return (const char *)_ptr; }
        inline const int addrlen() const { return 0; }
		inline const AbaxDataString toString()  const { return ""; }
        long hashCode() const { return 1; } 
        void destroy( AbaxDestroyAction action ) { 
            if ( _ptr ) {
                if ( action == ABAX_FREE ) { free( _ptr ); } 
                _ptr = NULL; 
            }
        }
		inline void valueDestroy( AbaxDestroyAction action ) { destroy(action); }

        static void * randomValue( int s ) {
            return (void*)0x83393;
        }

        inline AbaxBuffer&  operator= ( const AbaxBuffer &p2 ) {
            _ptr = p2._ptr; return *this;
        }
        inline AbaxBuffer&  copyKey( const AbaxBuffer &p2 ) {
            _ptr = p2._ptr; return *this;
        }

        inline AbaxBuffer&  operator= ( void *ptr ) {
            _ptr = ptr; return *this;
        }

        inline int operator== ( const AbaxBuffer &p2 )  const {
            return (_ptr == p2._ptr );
        }
        inline int operator!= ( const AbaxBuffer &p2 )  const {
            return ( ! (_ptr == p2._ptr ) );
        }
        inline int operator< ( const AbaxBuffer &p2 ) const {
            return (_ptr < p2._ptr );
        }
        inline int operator<= ( const AbaxBuffer &p2 ) const {
            return (_ptr <= p2._ptr );
        }
        inline  int operator> ( const AbaxBuffer &p2 ) const {
            return (_ptr > p2._ptr );
        }
        inline  int operator>= ( const AbaxBuffer &p2 ) const {
            return (_ptr >= p2._ptr );
        }

		inline AbaxBuffer& operator += ( const AbaxBuffer &p2 ) {
			return *this;
		}

        inline int toInt() const { return 0; }

    private:
        void *_ptr;

};


// typedef of data types
typedef AbaxNumeric<long> AbaxLong;
typedef AbaxNumeric<int> AbaxInt;
typedef AbaxNumeric<short> AbaxShort;
typedef AbaxNumeric<float> AbaxFloat;
typedef AbaxNumeric<double> AbaxDouble;
typedef AbaxNumeric<char> AbaxChar;



template <class KType>
int compareString( const KType &s1, const KType &s2,  const AbaxFormat &fmt )
{
	// key1:  "abcd,100,andfdf"
	// key2:  "fdfhjj,10,hello"
	// key2:  "2344,310,hello"
	// key2:  "ssss310hello"
	if ( ! KType::isString() ) return 0;
	char *str1 = (char*)s1.addr(); 
	char *str2 = (char*)s2.addr(); 

	register int i, j;
	register char *p1, *p2;
	int len;
	char sep;
	unsigned long acc1, acc2;

	if ( NULL == str1 && NULL == str2 ) return 0;
	if ( NULL == str1 && NULL != str2 ) return -1;
	if ( NULL != str1 && NULL == str2 ) return 1;


	// fmt.lenarr  fmt.separr  fmt.typearr
	p1 = (char*)str1;
	p2 = (char*)str2;
	for ( i = 0; i < fmt.len; ++i )
	{
	 	len = fmt.lenarr[i];
	 	sep = fmt.separr[i];
		if ( fmt.typearr[i] == 's' ) 
		{
			j = 0;
    		while ( *p1 != sep && *p1 != '\0' && *p2 != sep && *p2 != '\0' ) 
			{
				if ( (int)*p1 < (int)*p2 ) return -1;
				if ( (int)*p1 > (int)*p2 ) return 1;
				++p1; ++p2; ++j;
				if ( len > 0 ) {
					if ( j >= len ) break;
				} 
			}

		} else {   // 'd'
			j = 0;
			acc1 = 0;
    		while ( *p1 != sep && *p1 != '\0' && isdigit(*p1) )  {
				acc1 *= 10;
				acc1 += *p1 - '0';
				++p1; ++j;
				if ( len > 0 ) {
					if ( j>=len) break;
				}
			}
			
			j = 0;
			acc2 = 0;
    		while ( *p2 != sep && *p2 != '\0' && isdigit(*p2) )  {
				acc2 *= 10;
				acc2 += *p2 - '0';
				++p2; ++j;
				if ( len > 0 ) {
					if ( j>=len) break;
				}
			}

			if ( acc1 < acc2 ) return -1;
			if ( acc1 > acc2 ) return 1;

		}

		if ( *p1 == sep || *p1 == '\0' ) {
			if ( *p2 != sep &&  *p2 != '\0' ) {
				return -1;
			}
		} else {
			if ( *p2 == sep || *p2 == '\0' ) {
				return 1;
			}
		}

		if ( *p1 == '\0' || *p2 == '\0' ) return 0;
		if ( sep ) { ++p1; ++p2; }

	}

	return 0;
}
////////////////////////////////////////////////////////////////////////////////////////////


// Key-Value pair type
template <class KType,class VType>
class AbaxPair
{
    template <class K2,class V2> friend abaxstream& operator<< ( abaxstream &os, const AbaxPair<K2, V2> & pair );

    public:

        KType key;
        VType value;

		static  AbaxPair  NULLVALUE;
        inline AbaxPair() {}

        inline AbaxPair( const KType &k) : key(k) {}
        inline AbaxPair( const KType &k, const VType &v) : key(k), value(v) {}
        inline int lt (const AbaxPair &d2, const AbaxFormat &fmt ) const
        {
			if ( fmt.len>0 && KType::isString() ) {
				return ( compareString<KType>(key, d2.key, fmt) < 0 ?1:0 );
			} else {
            	return ( key < d2.key );
			}
        }


        inline int operator< ( const AbaxPair &d2 ) const {
           	return ( key < d2.key );
		}
        inline int operator<= ( const AbaxPair &d2 ) const {
           	return ( key <= d2.key );
		}
        inline int le (const AbaxPair &d2, const AbaxFormat &fmt ) const
        {
			if ( fmt.len>0 && KType::isString() ) {
				return ( compareString<KType>(key, d2.key, fmt) <= 0 ?1:0 );
			} else {
            	return ( key <= d2.key );
			}
        }
        inline int operator> ( const AbaxPair &d2 ) const {
           	return ( key > d2.key );
		}
        inline int operator>= ( const AbaxPair &d2 ) const {
           	return ( key >= d2.key );
		}

        inline int gt ( const AbaxPair &d2, const AbaxFormat &fmt ) const
        {
			if ( fmt.len>0 && KType::isString() ) {
				return ( compareString<KType>(key, d2.key, fmt) > 0 ?1:0 );
			} else {
            	return ( key > d2.key );
			}
        }
        inline int ge ( const AbaxPair &d2, const AbaxFormat &fmt ) const
        {
			if ( fmt.len>0 && KType::isString() ) {
				return ( compareString<KType>(key, d2.key, fmt) >= 0 ?1:0 );
			} else {
            	return ( key >= d2.key );
			}
        }
        inline int operator== ( const AbaxPair &d2 ) const
        {
           	return ( key == d2.key );
        }
        inline int operator!= ( const AbaxPair &d2 ) const
        {
            return ( ! ( key == d2.key ) );
        }

        inline int compare( const AbaxPair &d2, const AbaxFormat &fmt ) const
        {
			if ( fmt.len>0 && KType::isString() ) {
				return ( compareString<KType>(key, d2.key, fmt) );
			} 

            if ( key < d2.key ) {
                return -1;
            } else if ( key > d2.key ) {
                return 1;
            } else {
                return 0;
            }
        }

        inline AbaxPair&  operator= ( const AbaxPair &d3 )
        {
            key = d3.key;
            value = d3.value;
            return *this;
        }

        inline AbaxPair&  copyKey ( const AbaxPair &d3 )
        {
            key = d3.key;
            return *this;
        }

        inline void setValue( const VType &newvalue ) {
            value = newvalue;
        }

		inline void valueDestroy( AbaxDestroyAction action ) {
			value.destroy( action );
		}

        inline long hashCode() const { return key.hashCode(); }


};


template <class VType>
class AbaxListNode 
{ 
    public:
        VType value; 
        AbaxListNode *next; 
};

/***
  Simple list class
***/
template <class VType>
class AbaxList
{
    template <class T> friend class AbaxListIterator;

    public:

        AbaxList(); 
        AbaxList(const AbaxList<VType>& list);
        ~AbaxList(); 

        void  	add( const VType &value ); 
        bool  	exist( const VType &value ); 
        inline 	bool     isEmpty() const { return ( head_ == NULL ); } 
        bool    remove( const VType &value, AbaxDestroyAction action=ABAX_NOOP );
        bool    replace( const VType &oldValue, const VType &newValue );
        void    print() const; 
		void    copy( const AbaxList &list );

        void    destroy( AbaxDestroyAction action=ABAX_NOOP ); 
        AbaxList<VType>&  operator= ( const AbaxList<VType> &list ); 
        inline unsigned long  size() const { return length_; }
		void 	concurrent( bool flag = true );

    private:
        AbaxListNode<VType>     *head_;
        unsigned long           length_; 
		AbaxReadWriteLock  		*_lock;
};



//////// Forward declarations ////////////

template <class K> class AbaxKeyPair;
template <class K, class V > class AbaxMatImpl;
template <class K, class V, class MatType, class Iter> class AbaxMatImplIterator;
template <class KType> class AbaxHashListImpl;
template <class T> class AbaxHashListImplInsertOrderIterator;
template <class T> class AbaxHashListImplInsertOrderReverseIterator;
template <class T> class AbaxHashListImplKeyOrderIterator;
template <class T> class AbaxHashListImplKeyOrderReverseIterator;
template <class KType> class AbaxCounterImpl;

template <class K > class AbaxFlatSetIterator;
template <class K > class AbaxFlatSetReverseIterator;
template <class K, class V > class AbaxFlatMapIterator;
template <class K, class V > class AbaxFlatMapReverseIterator;


// Light-weight object with a reference to key only
template <class K >
class AbaxKey
{ 
    public: 

    AbaxKey(const K &k ): key(k) {};
    AbaxKey(const AbaxKey<K> &ref) : key(ref.key) {};
    AbaxKey(AbaxKeyPair<K> &pair); 

    const K &key; 
};

// Light-weight class containing only references to key-vaue
template <class K, class V>
class AbaxKeyValue
{ 
    public: 

    AbaxKeyValue(const K &k, V &v): key(k), value(v) {};
    AbaxKeyValue(const K &k ): key(k) {};
    AbaxKeyValue(const AbaxKeyValue<K,V> &ref) : key(ref.key), value(ref.value) {};

    const K &key; 
    V &value; 
};

// Light-weight class with pointers pointing to key-value
template <class K, class V>
class AbaxPtrKeyValue
{ 
    public: 

    AbaxPtrKeyValue(K *k, V *v): key(k), value(v) {};
    AbaxPtrKeyValue(K *k ): key(k) {};
    AbaxPtrKeyValue(const AbaxPtrKeyValue<K,V> &p2) : key(p2.key), value(p2.value) {};

    K *key; 
    V *value; 
};



/***
This is one of the main Abax classes.
Map class contains a set of key-value pairs
Type of key is K, type of value is V.
***/
template <class K, class V>
class AbaxMap
{
    template <class K2, class V2> friend class AbaxMapIterator;
    template <class K2, class V2> friend class AbaxMapReverseIterator;

    public: 

        AbaxMap();
        ~AbaxMap();

        bool addKeyValue( const K& key, const V& value );
        bool keyExist(  const K& key );
        bool getValue( const K& key, V &value );
        bool setValue( const K& key, const V& value );
        bool removeKey( const K& key, AbaxDestroyAction action=ABAX_NOOP  );
        unsigned long size( ) const ;
		void setFormat( const char *fmt );
		long getShifts() const; 
		void print() const; 
		void concurrent( bool flag = true );

        const AbaxPair<K,V> *array() const { return _flatmap->array(); }
        inline long arrayLength( ) const  { return _flatmap->size(); }
        inline bool isNull( abaxint i ) const { return _flatmap->isNull(i); }


    private:
        AbaxFlatMap<K,V >  *_flatmap; 
		AbaxReadWriteLock  *_lock;
};


/***
This is one of the main Abax classes.
MultiMap class contains a set of key-value pairs. Multiple records for the same key can exist.
Type of key is K, type of value is V.
***/
template <class K, class V>
class AbaxMultiMap
{
    template <class K2, class V2> friend class AbaxMultiMapIterator;
    template <class K2, class V2> friend class AbaxMultiMapReverseIterator;

    public: 

        AbaxMultiMap( );
        ~AbaxMultiMap();

        bool addKeyValue( const K &key, const V &value );
        bool setKeyValue( const K &key, const V &oldValue, const V &newValue  );
        bool removeKeyValue( const K &key, const V &Value, AbaxDestroyAction action=ABAX_NOOP  ); 
        bool removeAllKeyValues( const K &key, AbaxDestroyAction action=ABAX_NOOP  ); 
        bool getKeyValues( const K &key, AbaxList<V> &retlist );
        bool keyValueExist( const K &key, const V &value );
        bool keyExist( const K &key );
        unsigned long size() const;
        unsigned long sizeAll() const;
		void setFormat( const char *fmt );
		void concurrent( bool flag = true );

    private:
        AbaxMatImpl<K,V >  *_dmatimpl; 
		AbaxReadWriteLock  *_lock;
};


/***
Iterator over an AbaxMap object
***/
template <class K, class V>
class AbaxMapIterator
{
    public: 

        AbaxMapIterator( AbaxMap<K,V> *satw );
        AbaxMapIterator( AbaxMap<K,V> *satw, unsigned long count );
        AbaxMapIterator( AbaxMap<K,V> *satw, const K& start );
        AbaxMapIterator( AbaxMap<K,V> *satw, const K& start, unsigned long count );
        AbaxMapIterator( AbaxMap<K,V> *satw, const K& start, const K& end );

        ~AbaxMapIterator();

        void  begin();
        bool   hasNext();
        AbaxKeyValue<K,V>  next( AbaxStepAction action=ABAX_NEXT );

    private:
        void  nextStep(); 
        AbaxMap<K,V> *_mapobj; 
        AbaxFlatMapIterator< K,V > *_diterimpl;
};


/***
Iterator over an AbaxMap object, moving in reverse order (from greatest key to least key).
***/
template <class K, class V>
class AbaxMapReverseIterator
{
    public: 

        AbaxMapReverseIterator( AbaxMap<K,V> *satw );
        AbaxMapReverseIterator( AbaxMap<K,V> *satw, unsigned long count );
        AbaxMapReverseIterator( AbaxMap<K,V> *satw, const K& start );
        AbaxMapReverseIterator( AbaxMap<K,V> *satw, const K& start, unsigned long count );
        AbaxMapReverseIterator( AbaxMap<K,V> *satw, const K& start, const K& end );

        ~AbaxMapReverseIterator();

        void  begin();
        bool   hasNext();
        AbaxKeyValue<K,V>  next( AbaxStepAction action=ABAX_NEXT );

    private:
        void  nextStep(); 
        AbaxMap<K,V> *_mapobj; 
        AbaxFlatMapReverseIterator< K,V > *_diterimpl;
};



/***
Raw iterator over a multi-map object.
***/
template <class K, class V>
class AbaxMultiMapIterator
{
    public: 

        AbaxMultiMapIterator( AbaxMultiMap<K,V> *matw );
        AbaxMultiMapIterator( AbaxMultiMap<K,V> *matw, unsigned long count );
        AbaxMultiMapIterator( AbaxMultiMap<K,V> *matw, const K& start );
        AbaxMultiMapIterator( AbaxMultiMap<K,V> *matw, const K& start, unsigned long count );
        AbaxMultiMapIterator( AbaxMultiMap<K,V> *matw, const K& start, const K& end );

        ~AbaxMultiMapIterator();

        void  begin();
        bool   hasNext();
        AbaxKeyValue<K,V>  next( AbaxStepAction action=ABAX_NEXT );

    private:
        void  nextStep(); 
        AbaxMultiMap<K,V> *_matobj; 

		AbaxMatImplIterator<K,V,AbaxMatImpl<K,V>,AbaxFlatMapIterator<K,AbaxList<V> > > * _diterimpl;
};


/***
Raw iterator over a multi-map object, in reverse direction.
***/
template <class K, class V>
class AbaxMultiMapReverseIterator
{
    public: 

        AbaxMultiMapReverseIterator( AbaxMultiMap<K,V> *matw );
        AbaxMultiMapReverseIterator( AbaxMultiMap<K,V> *matw, unsigned long count );
        AbaxMultiMapReverseIterator( AbaxMultiMap<K,V> *matw, const K& start );
        AbaxMultiMapReverseIterator( AbaxMultiMap<K,V> *matw, const K& start, unsigned long count );
        AbaxMultiMapReverseIterator( AbaxMultiMap<K,V> *matw, const K& start, const K& end );

        ~AbaxMultiMapReverseIterator();

        void  begin();
        bool   hasNext();
        AbaxKeyValue<K,V>  next( AbaxStepAction action=ABAX_NEXT );


    private:
        void  nextStep(); 
        AbaxMultiMap<K,V> *_matobj; 
        AbaxMatImplIterator<K,V,AbaxMatImpl<K,V >,AbaxFlatMapReverseIterator<K,AbaxList<V> > >  *_diterimpl; 
};


// Forward declarations for AbaxSet
template <class K> class AbaxKeyPair;
template <class K > class AbaxMSetImpl;
template <class K, class MatType, class Iter> class AbaxMSetImplIterator;
template <class T> class AbaxNumeric; 


/***
Abaxset 
***/
template <class K>
class AbaxSet
{
    template <class K2 > friend class AbaxSetIterator;
    template <class K2> friend class AbaxSetReverseIterator;

    public: 

        AbaxSet( );
        ~AbaxSet();

        bool addKey( const K& key );
        bool removeKey( const K& key );
        bool keyExist(  const K& key );

        unsigned long size( ) const ;
		void 	setFormat( const char *fmt );
		void concurrent( bool flag = true );

    private:
		AbaxFlatSet<K> *_flatset;
		AbaxReadWriteLock  *_lock;
};


/***
Multiset class
***/
template <class K>
class AbaxMultiSet
{
    template <class K2 > friend class AbaxMultiSetIterator;
    template <class K2 > friend class AbaxMultiSetReverseIterator;

    public: 

        AbaxMultiSet( );
        ~AbaxMultiSet();

        bool addKey( const K &key );
        bool removeKey( const K &key ); 
        bool removeAllKeys( const K &key ); 
        bool keyExist( const K &key );
        unsigned long getKeyCount( const K &key );

        unsigned long size() const;
        unsigned long sizeAll() const;
		void 	setFormat( const char *fmt );
		void concurrent( bool flag = true );


    private:
        AbaxMSetImpl<K >  *_dmsetimpl; 
		AbaxReadWriteLock  *_lock;
};


/***
Raw iterator of a set
***/
template <class K>
class AbaxSetIterator
{
    public: 

        AbaxSetIterator( AbaxSet<K> *setw );
        AbaxSetIterator( AbaxSet<K> *setw, unsigned long count );
        AbaxSetIterator( AbaxSet<K> *setw, const K& start );
        AbaxSetIterator( AbaxSet<K> *setw, const K& start, unsigned long count );
        AbaxSetIterator( AbaxSet<K> *setw, const K& start, const K& end );

        ~AbaxSetIterator();

        void  begin();
        bool   hasNext();
        const K&  next( AbaxStepAction action=ABAX_NEXT );

    private:
        AbaxSet<K> *_setobj; 
		AbaxFlatSetIterator<K> *_flatsetiter;
};


/***
Raw iterator of a set in reverse direction
***/
template <class K>
class AbaxSetReverseIterator
{
    public: 

        AbaxSetReverseIterator( AbaxSet<K> *setw );
        AbaxSetReverseIterator( AbaxSet<K> *setw, unsigned long count );
        AbaxSetReverseIterator( AbaxSet<K> *setw, const K& start );
        AbaxSetReverseIterator( AbaxSet<K> *setw, const K& start, unsigned long count );
        AbaxSetReverseIterator( AbaxSet<K> *setw, const K& start, const K& end );

        ~AbaxSetReverseIterator();

        void  	begin();
        bool   	hasNext();
        const K&   next( AbaxStepAction action=ABAX_NEXT );


    private:
        AbaxSet<K> *_setobj; 
		AbaxFlatSetReverseIterator<K> *_flatsetiter;
};


/***
Multiset raw iterator
**/
template <class K >
class AbaxMultiSetIterator
{
    public: 

        AbaxMultiSetIterator( AbaxMultiSet<K> *msetw );
        AbaxMultiSetIterator( AbaxMultiSet<K> *msetw, unsigned long count );
        AbaxMultiSetIterator( AbaxMultiSet<K> *msetw, const K& start );
        AbaxMultiSetIterator( AbaxMultiSet<K> *msetw, const K& start, unsigned long count );
        AbaxMultiSetIterator( AbaxMultiSet<K> *msetw, const K& start, const K& end );

        ~AbaxMultiSetIterator();

        void  	begin();
        bool   	hasNext();
        const K&  next( AbaxStepAction action=ABAX_NEXT );

    private:
        void  nextStep(); 
        AbaxMultiSet<K> *_msetw; 

        AbaxMSetImplIterator<K,AbaxMSetImpl<K >,
                AbaxFlatSetIterator<AbaxPair<K,AbaxLong > > >  *_diterimpl; 
};


/***
Multiset raw reverse iterator
**/
template <class K >
class AbaxMultiSetReverseIterator
{
    public: 

        AbaxMultiSetReverseIterator( AbaxMultiSet<K> *msetw );
        AbaxMultiSetReverseIterator( AbaxMultiSet<K> *msetw, unsigned long count );
        AbaxMultiSetReverseIterator( AbaxMultiSet<K> *msetw, const K& start );
        AbaxMultiSetReverseIterator( AbaxMultiSet<K> *msetw, const K& start, unsigned long count );
        AbaxMultiSetReverseIterator( AbaxMultiSet<K> *msetw, const K& start, const K& end );

        ~AbaxMultiSetReverseIterator();

        void  	begin();
        bool   	hasNext();
        const K&  next( AbaxStepAction action=ABAX_NEXT );

    private:
        void  nextStep(); 
        AbaxMultiSet<K> *_msetw; 

        AbaxMSetImplIterator<K,AbaxMSetImpl<K >,
                AbaxFlatSetReverseIterator<AbaxPair<K,AbaxLong > > >  *_diterimpl; 

};



/***
Hashed linked list class
***/
template <class KType>
class AbaxHashList
{
    template <class K2> friend class AbaxHashListIterator;
    template <class K2> friend class AbaxHashListReverseIterator;

    template <class K2> friend class AbaxHashListKeyIterator;
    template <class K2> friend class AbaxHashListKeyReverseIterator;

    public: 

        AbaxHashList( ); 
        ~AbaxHashList();

        void    addHead( const KType &key );
        void    addTail( const KType &key );
        bool    removeHead();
        bool    removeTail();
        bool    removeKey( const KType &key );
        bool    keyExist( const KType &key );
        void    print(); 
        unsigned long  size( );
		void concurrent( bool flag = true );

    private:
        AbaxHashListImpl<KType> *_hashlist;
		AbaxReadWriteLock  *_lock;
};


/***
Hash List iterator
***/
template <class K>
class AbaxHashListIterator
{
    public: 

        AbaxHashListIterator( AbaxHashList<K> *hashlist );
        AbaxHashListIterator( AbaxHashList<K> *hashlist, unsigned long count );
        ~AbaxHashListIterator();

        void          begin();
        bool          hasNext();
        const K&      next( AbaxStepAction action=ABAX_NEXT );


    private:
        void  nextStep(); 
        AbaxHashList<K> *_hlist;
        AbaxHashListImplInsertOrderIterator<K> *_iterimpl;
};

/***
Hash List reverse iterator
***/
template <class K>
class AbaxHashListReverseIterator
{
    public: 

        AbaxHashListReverseIterator( AbaxHashList<K> *hashlist );
        AbaxHashListReverseIterator( AbaxHashList<K> *hashlist, unsigned long count );

        ~AbaxHashListReverseIterator();

        void  	begin();
        bool   	hasNext();
        const 	K&   next( AbaxStepAction action=ABAX_NEXT );


    private:
        void  nextStep(); 
        AbaxHashList<K> *_hlist;
        AbaxHashListImplInsertOrderReverseIterator<K> *_iterimpl;
};


/***
Hash List sorted iterator
***/
template <class K>
class AbaxHashListKeyIterator
{
    public: 

        AbaxHashListKeyIterator( AbaxHashList<K> *hashlist );
        AbaxHashListKeyIterator( AbaxHashList<K> *hashlist, unsigned long count );
        AbaxHashListKeyIterator( AbaxHashList<K> *hashlist, const K& start );
        AbaxHashListKeyIterator( AbaxHashList<K> *hashlist, const K& start, unsigned long count );
        AbaxHashListKeyIterator( AbaxHashList<K> *hashlist, const K& start, const K& end );

        ~AbaxHashListKeyIterator();

        void  	begin();
        bool   	hasNext();
        const 	K& next( AbaxStepAction action=ABAX_NEXT );


    private:
        void  nextStep(); 
        AbaxHashList<K> *_hlist;
        AbaxHashListImplKeyOrderIterator<K> *_iterimpl;
};


/***
Hash List reverse iterator for sorted keys
***/
template <class K>
class AbaxHashListKeyReverseIterator
{
    public: 

        AbaxHashListKeyReverseIterator( AbaxHashList<K> *hashlist );
        AbaxHashListKeyReverseIterator( AbaxHashList<K> *hashlist, unsigned long count );
        AbaxHashListKeyReverseIterator( AbaxHashList<K> *hashlist, const K& start );
        AbaxHashListKeyReverseIterator( AbaxHashList<K> *hashlist, const K& start, unsigned long count );
        AbaxHashListKeyReverseIterator( AbaxHashList<K> *hashlist, const K& start, const K& end );

        ~AbaxHashListKeyReverseIterator();

        void   begin();
        bool   hasNext();
        const K&     next( AbaxStepAction action=ABAX_NEXT );


    private:
        void  nextStep(); 
        AbaxHashList<K> *_hlist;
        AbaxHashListImplKeyOrderReverseIterator<K> *_iterimpl;
};


/***
AbaxCounter 
***/
template <class KType>
class AbaxCounter
{
    template <class T> friend class AbaxCounterKeyIterator;
    template <class T> friend class AbaxCounterKeyReverseIterator;
    template <class T> friend class AbaxCounterCountIterator;
    template <class T> friend class AbaxCounterCountReverseIterator;

    public: 

        AbaxCounter( ); 
        ~AbaxCounter();

        void     addKey( const KType &key );
        void     removeKey( const KType &key );
        void     removeAllKeys( const KType &key );
        bool     keyExist( const KType &key );
        unsigned long getKeyCount( const KType &key );

        unsigned long size() const;
        unsigned long sizeAll() const;
		void     setFormat( const char *fmt );
		void concurrent( bool flag = true );


    private:
        AbaxCounterImpl<KType> *_counter;
		AbaxReadWriteLock  *_lock;
};

/***
Iterator of an AbaxCounter object.
***/
template <class K>
class AbaxCounterKeyIterator
{
    public: 

        AbaxCounterKeyIterator( AbaxCounter<K> *counter );
        AbaxCounterKeyIterator( AbaxCounter<K> *counter, unsigned long count );
        ~AbaxCounterKeyIterator();

        void      begin();
        bool      hasNext();
        const K&  next( AbaxStepAction action=ABAX_NEXT );

    private:
        void  nextStep(); 
        AbaxCounter<K> *_counter;

        AbaxMSetImplIterator<K,AbaxMSetImpl<K >, 
                AbaxFlatSetIterator< AbaxPair<K,AbaxLong> > >  *_iterimpl; 

};

/***
Iterator of an AbaxCounter object. Keys are output in reverse direction.
***/
template <class K>
class AbaxCounterKeyReverseIterator
{
    public: 

        AbaxCounterKeyReverseIterator( AbaxCounter<K> *counter );
        AbaxCounterKeyReverseIterator( AbaxCounter<K> *counter, unsigned long count );
        ~AbaxCounterKeyReverseIterator();

        void      	begin();
        bool   		hasNext();
        const K&    next( AbaxStepAction action=ABAX_NEXT );

    private:
        void  nextStep(); 
        AbaxCounter<K> *_counter;

        AbaxMSetImplIterator<K,AbaxMSetImpl<K >, 
                AbaxFlatSetReverseIterator< AbaxPair<K,AbaxLong>  > >  *_iterimpl; 
};


/***
Iterator of an AbaxCounter object. Keys are output with sorted counts in ascending order.
***/
template <class K>
class AbaxCounterCountIterator
{
    public: 

        AbaxCounterCountIterator( AbaxCounter<K> *counter );
        AbaxCounterCountIterator( AbaxCounter<K> *counter, unsigned long bottom );
        AbaxCounterCountIterator( AbaxCounter<K> *counter, unsigned long count, unsigned long num );

        ~AbaxCounterCountIterator();

        void      begin();
        bool      hasNext();
        const AbaxString&  next( AbaxStepAction action=ABAX_NEXT );

    private:
        void  nextStep(); 
        AbaxCounter<K> *_counter;
        AbaxFlatSetIterator< AbaxKeyPair<AbaxString>  > *_iterimpl;
};


/***
Iterator of an AbaxCounter object. Keys are output with sorted counts in descending order.
***/
template <class K>
class AbaxCounterCountReverseIterator
{
    public: 

        AbaxCounterCountReverseIterator( AbaxCounter<K> *counter );
        AbaxCounterCountReverseIterator( AbaxCounter<K> *counter, unsigned long top );
        AbaxCounterCountReverseIterator( AbaxCounter<K> *counter, unsigned long count, unsigned long num );

        ~AbaxCounterCountReverseIterator();

        void   begin();
        bool   hasNext();
        const  AbaxString&  next( AbaxStepAction action=ABAX_NEXT );

    private:
        void  nextStep(); 
        AbaxCounter<K> *_counter;
        AbaxFlatSetReverseIterator< AbaxKeyPair<AbaxString>  > *_iterimpl;
};

template <class VType>
class AbaxListIterator
{
    public:

        AbaxListIterator();
        AbaxListIterator( AbaxList<VType> *list );

        ~AbaxListIterator( ); 
        void init( AbaxList<VType> *list );

        void begin();
        inline AbaxListIterator&  operator++() { nextStep(); return *this; }
        inline bool  hasNext() const { return ptr_ != NULL; }
        VType* 		ptrNext();
        VType& 		refNext();
        VType& 		next() { VType &ref = refNext(); nextStep(); return ref; };
        void        nextStep();

    private:
        AbaxList<VType> 	* list_;
        AbaxListNode<VType> *ptr_;
        bool  				_doneBegin;
};


class abaxstream
{
	public:

	abaxstream & operator<< ( const char *str );
	abaxstream & operator<< ( int n );
	abaxstream & operator<< ( unsigned int n );
	abaxstream & operator<< ( unsigned char n );
	abaxstream & operator<< ( unsigned short n );
	abaxstream & operator<< ( float f);
	abaxstream & operator<< ( double d);
	abaxstream & operator<< ( long l );
	abaxstream & operator<< ( unsigned long l );
	abaxstream & operator<< ( const AbaxDataString &str );
};
extern abaxstream abaxcout;
extern const char* abaxendl; 

// Clock Class
class AbaxClock
{
    public:
    AbaxClock()
    {
        endsec = beginsec = endmsec = beginmsec = 0; 
    }

    void start()
    {
        timeval now;
        gettimeofday( &now, NULL ); 
        endsec = beginsec = now.tv_sec;
        endmsec = beginmsec = now.tv_usec/1000;
        endusec = beginusec = now.tv_usec;
    }

    void stop()
    {
        timeval now;
        gettimeofday( &now, NULL ); 
        endsec = now.tv_sec;
        endmsec = now.tv_usec/1000;
        endusec = now.tv_usec;
    }

    // return elapsed time in milliseconds
    int elapsed()
    {
        return ( 1000*(endsec - beginsec) + ( endmsec - beginmsec ) );
    }
    int elapsedusec()
    {
        return ( 1000000*(endsec-beginsec) + ( endusec - beginusec ) );
    }

    private:
        int  beginsec, beginmsec, beginusec;
        int  endsec, endmsec, endusec;

};


// Memory Class
class AbaxMemory
{
    public:
    AbaxMemory()
    {
        endkb = beginkb = 0; 
    }

    void start()
    {
		beginkb = snapShot();
    }

    void stop()
    {
		endkb = snapShot();
    }

    // return memory usage in KB
    int used()
    {
        return endkb; 
    }

    // return incremented memory usage in KB
    int diff()
    {
        return ( endkb - beginkb );
    }

    private:
        int  beginkb, endkb; 
		int snapShot()
        {
            char *ptr;
            int sz;
            char fn[256];
            static char line[256];
            pid_t pid = getpid();
            sprintf(fn, "/proc/%d/status", pid );
        
            FILE *fp = fopen(fn, "r");
            if ( ! fp ) return 0;
        
            while ( NULL != fgets( line, 256, fp) ) {
                sz = strlen(line);
                if ( strstr( line, "VmRSS:") ) {
                    fclose( fp );
                    line[sz-1]='\0';
                    ptr = &line[7];
                    while ( ! isdigit(*ptr) ) ptr++;
                    return atoi(ptr);
                }
            }
            fclose( fp );
            return 0;
        }

};


// Key-key-Value pair type
template <class KType,class VType>
class AbaxKeyKeyPair
{
    template <class K2,class V2> friend abaxstream& operator<< (abaxstream &os, const AbaxKeyKeyPair<K2, V2> & pair );

    public:

        KType key1;
        KType key2;
        VType value;

		static  AbaxKeyKeyPair  NULLVALUE; 
		static const long   HALFMAX = LONG_MAX >> 1;

        inline AbaxKeyKeyPair() {}
        inline AbaxKeyKeyPair( const KType &k1 ) : key1(k1), key2(k1) {}
        inline AbaxKeyKeyPair( const KType &k1, const KType &k2) : key1(k1), key2(k2) {}
        inline AbaxKeyKeyPair( const KType &k1, const KType &k2, const VType &v) : key1(k1), key2(k2), value(v) {}

        inline int operator< (const AbaxKeyKeyPair &d2 ) const
        {
           	return ( key1 < d2.key1 || ( key1==d2.key1 && key2<d2.key2 ) );
        }
        inline int operator<= (const AbaxKeyKeyPair &d2 ) const
        {
           	return ( key1 < d2.key1 || ( key1==d2.key1 && key2<=d2.key2 ) );
        }

        inline int operator> ( const AbaxKeyKeyPair &d2 ) const
        {
           	return ( key1 > d2.key1 || ( key1==d2.key1 && key2>d2.key2 ) );
        }

        inline int operator>= ( const AbaxKeyKeyPair &d2 ) const
        {
           	return ( key1 > d2.key1 || ( key1==d2.key1 && key2>=d2.key2 ) );
        }

		/*********
        inline int lt (const AbaxKeyKeyPair &d2, const AbaxFormat &fmt ) const
        {
           	return ( key1 < d2.key1 || ( key1==d2.key1 && key2<d2.key2 ) );
        }
        inline int le (const AbaxKeyKeyPair &d2, const AbaxFormat &fmt ) const
        {
           	return ( key1 < d2.key1 || ( key1==d2.key1 && key2<=d2.key2 ) );
        }
        inline int gt ( const AbaxKeyKeyPair &d2, const AbaxFormat &fmt ) const
        {
           	return ( key1 > d2.key1 || ( key1==d2.key1 && key2>d2.key2 ) );
        }
        inline int ge ( const AbaxKeyKeyPair &d2, const AbaxFormat &fmt ) const
        {
           	return ( key1 > d2.key1 || ( key1==d2.key1 && key2>=d2.key2 ) );
        }
		*****/
        int lt (const AbaxKeyKeyPair &d2, const AbaxFormat &fmt ) const
        {
			int rc1, rc2;
			if ( fmt.len>0 && KType::isString() ) {
				rc1 = compareString<AbaxString>( key1, d2.key1, fmt); 
				if ( rc1 < 0 ) { return 1; }
				else if ( 0 == rc1 ) {
					rc2 = compareString<AbaxString>( key2, d2.key2, fmt); 
					return ( (rc2<0) ?  1 : 0 );
				} else {
					return 0;
				}
			} else {
           		return ( key1 < d2.key1 || ( key1==d2.key1 && key2<d2.key2 ) );
			}
        }

        int le (const AbaxKeyKeyPair &d2, const AbaxFormat &fmt ) const
        {
			int rc1, rc2;
			if ( fmt.len>0 && KType::isString() ) {
				rc1 = compareString<AbaxString>( key1, d2.key1, fmt); 
				if ( rc1 < 0 ) { return 1; }
				else if ( 0 == rc1 ) {
					rc2 = compareString<AbaxString>( key2, d2.key2, fmt); 
					return ( (rc2<=0) ?  1 : 0 );
				} else {
					return 0;
				}
			} else {
           		return ( key1 < d2.key1 || ( key1==d2.key1 && key2<=d2.key2 ) );
			}
        }

        int gt (const AbaxKeyKeyPair &d2, const AbaxFormat &fmt ) const
        {
			int rc1, rc2;
			if ( fmt.len>0 && KType::isString() ) {
				rc1 = compareString<AbaxString>( key1, d2.key1, fmt); 
				if ( rc1 > 0 ) { return 1; }
				else if ( 0 == rc1 ) {
					rc2 = compareString<AbaxString>( key2, d2.key2, fmt); 
					return ( (rc2>0) ?  1 : 0 );
				} else {
					return 0;
				}
			} else {
           		return ( key1 > d2.key1 || ( key1==d2.key1 && key2>d2.key2 ) );
			}
        }

        int ge (const AbaxKeyKeyPair &d2, const AbaxFormat &fmt ) const
        {
			int rc1, rc2;
			if ( fmt.len>0 && KType::isString() ) {
				rc1 = compareString<AbaxString>( key1, d2.key1, fmt); 
				if ( rc1 > 0 ) { return 1; }
				else if ( 0 == rc1 ) {
					rc2 = compareString<AbaxString>( key2, d2.key2, fmt); 
					return ( (rc2>=0) ?  1 : 0 );
				} else {
					return 0;
				}
			} else {
           		return ( key1 > d2.key1 || ( key1==d2.key1 && key2>=d2.key2 ) );
			}
        }



        inline int operator== ( const AbaxKeyKeyPair &d2 ) const
        {
           	return ( key1 == d2.key1 && key2==d2.key2 );
        }
        inline int operator!= ( const AbaxKeyKeyPair &d2 ) const
        {
           	return ( ! ( key1 == d2.key1 && key2==d2.key2 ) );
        }
        inline int isKey1Null() const
        {
           	return ( key1 == KType::NULLVALUE );
        }
        inline int isKey2Null() const
        {
           	return ( key2 == KType::NULLVALUE );
        }

        inline int compare( const AbaxKeyKeyPair &d2, const AbaxFormat &fmt ) const
        {
            if ( lt(d2, fmt) ) {
                return -1;
            } else if ( gt( d2, fmt) ) {
                return 1;
            } else {
                return 0;
            }
        }

        inline AbaxKeyKeyPair&  operator= ( const AbaxKeyKeyPair &d2 )
        {
            key1 = d2.key1;
            key2 = d2.key2;
            value = d2.value;
            return *this;
        }

        inline void setValue( const VType &newvalue ) {
            value = newvalue;
        }

		inline void valueDestroy( AbaxDestroyAction action ) {
			value.destroy( action );
		}

        inline long hashCode() const { 

			long h1 = key1.hashCode(); 
			if ( isKey2Null() ) return h1;

			long h2 = key2.hashCode(); 
			if ( isKey1Null() ) return  h2;

			if ( h1 < HALFMAX ) {
				return h1+ (h2>>1);
			} else {
				return (h1 >> 1) + (h2 >> 2);
			}
		}
};


// Key-key type
template <class KType>
class AbaxKeyKey
{
    template <class K2,class V2> friend abaxstream& operator<< (abaxstream &os, const AbaxKeyKeyPair<K2, V2> & pair );

    public:

        KType key1;
        KType key2;

		static  AbaxKeyKey  NULLVALUE; 
		static const long   HALFMAX = LONG_MAX >> 1;

        inline AbaxKeyKey() {}
        inline AbaxKeyKey( const KType &k1 ) : key1(k1), key2(k1) {}
        inline AbaxKeyKey( const KType &k1, const KType &k2) : key1(k1), key2(k2) {}

        inline int operator< (const AbaxKeyKey &d2 ) const
        {
           	return ( key1 < d2.key1 || ( key1==d2.key1 && key2<d2.key2 ) );
        }
        inline int operator<= (const AbaxKeyKey &d2 ) const
        {
           	return ( key1 < d2.key1 || ( key1==d2.key1 && key2<=d2.key2 ) );
        }

        inline int operator> ( const AbaxKeyKey &d2 ) const
        {
           	return ( key1 > d2.key1 || ( key1==d2.key1 && key2>d2.key2 ) );
        }

        inline int operator>= ( const AbaxKeyKey &d2 ) const
        {
           	return ( key1 > d2.key1 || ( key1==d2.key1 && key2>=d2.key2 ) );
        }

        int lt (const AbaxKeyKey &d2, const AbaxFormat &fmt ) const
        {
			int rc1, rc2;
			if ( fmt.len>0 && KType::isString() ) {
				rc1 = compareString<AbaxString>( key1, d2.key1, fmt); 
				if ( rc1 < 0 ) { return 1; }
				else if ( 0 == rc1 ) {
					rc2 = compareString<AbaxString>( key2, d2.key2, fmt); 
					return ( (rc2<0) ?  1 : 0 );
				} else {
					return 0;
				}
			} else {
           		return ( key1 < d2.key1 || ( key1==d2.key1 && key2<d2.key2 ) );
			}
        }

        int le (const AbaxKeyKey &d2, const AbaxFormat &fmt ) const
        {
			int rc1, rc2;
			if ( fmt.len>0 && KType::isString() ) {
				rc1 = compareString<AbaxString>( key1, d2.key1, fmt); 
				if ( rc1 < 0 ) { return 1; }
				else if ( 0 == rc1 ) {
					rc2 = compareString<AbaxString>( key2, d2.key2, fmt); 
					return ( (rc2<=0) ?  1 : 0 );
				} else {
					return 0;
				}
			} else {
           		return ( key1 < d2.key1 || ( key1==d2.key1 && key2<=d2.key2 ) );
			}
        }

        int gt (const AbaxKeyKey &d2, const AbaxFormat &fmt ) const
        {
			int rc1, rc2;
			if ( fmt.len>0 && KType::isString() ) {
				rc1 = compareString<AbaxString>( key1, d2.key1, fmt); 
				if ( rc1 > 0 ) { return 1; }
				else if ( 0 == rc1 ) {
					rc2 = compareString<AbaxString>( key2, d2.key2, fmt); 
					return ( (rc2>0) ?  1 : 0 );
				} else {
					return 0;
				}
			} else {
           		return ( key1 > d2.key1 || ( key1==d2.key1 && key2>d2.key2 ) );
			}
        }

        int ge (const AbaxKeyKey &d2, const AbaxFormat &fmt ) const
        {
			int rc1, rc2;
			if ( fmt.len>0 && KType::isString() ) {
				rc1 = compareString<AbaxString>( key1, d2.key1, fmt); 
				if ( rc1 > 0 ) { return 1; }
				else if ( 0 == rc1 ) {
					rc2 = compareString<AbaxString>( key2, d2.key2, fmt); 
					return ( (rc2>=0) ?  1 : 0 );
				} else {
					return 0;
				}
			} else {
           		return ( key1 > d2.key1 || ( key1==d2.key1 && key2>=d2.key2 ) );
			}
        }



        inline int operator== ( const AbaxKeyKey &d2 ) const
        {
           	return ( key1 == d2.key1 && key2==d2.key2 );
        }
        inline int operator!= ( const AbaxKeyKey &d2 ) const
        {
           	return ( ! ( key1 == d2.key1 && key2==d2.key2 ) );
        }
        inline int isKey1Null() const
        {
           	return ( key1 == KType::NULLVALUE );
        }
        inline int isKey2Null() const
        {
           	return ( key2 == KType::NULLVALUE );
        }

        inline int compare( const AbaxKeyKey &d2, const AbaxFormat &fmt ) const
        {
            if ( lt(d2, fmt) ) {
                return -1;
            } else if ( gt( d2, fmt) ) {
                return 1;
            } else {
                return 0;
            }
        }

        inline AbaxKeyKey&  operator= ( const AbaxKeyKey &d2 )
        {
            key1 = d2.key1;
            key2 = d2.key2;
            return *this;
        }

        inline long hashCode() const { 

			long h1 = key1.hashCode(); 
			if ( isKey2Null() ) return h1;

			long h2 = key2.hashCode(); 
			if ( isKey1Null() ) return  h2;

			if ( h1 < HALFMAX ) {
				return h1+ (h2>>1);
			} else {
				return (h1 >> 1) + (h2 >> 2);
			}
		}
};


template <class K2, class V2> class AbaxHashMapIterator;
template <class Pair> class AbaxHashArray;

/***
	Key-Value hash map
***/
template <class K, class V>
class AbaxHashMap 
{

    template <class K2, class V2> friend class AbaxHashMapIterator;

    public: 

        AbaxHashMap(  );
        ~AbaxHashMap() { destroy(); }

        bool addKeyValue( const K& key, const V& value );
        bool keyExist(  const K& key );
        bool getValue( const K& key, V &value );
        bool setValue( const K& key, const V& value );
        bool removeKey( const K& key, AbaxDestroyAction action=ABAX_NOOP  );
        long size( ) const;
		void  destroy(); 
		const AbaxPair<K,V> *array() const; 
        long arrayLength( ) const;
		bool isNull( long i ) const;
		void print() const; 
		void concurrent( bool flag = true );


    private:
        AbaxHashArray<AbaxPair<K,V> >  *_xarr; 
		AbaxReadWriteLock  *_lock;

};

/***
  Iterator of AbaxHashMap
***/
template <class K, class V>
class AbaxHashMapIterator
{
    public: 

        AbaxHashMapIterator( AbaxHashMap<K,V> *hmap );
        AbaxHashMapIterator( AbaxHashMap<K,V> *hmap, unsigned long count );
        ~AbaxHashMapIterator();

        void  	begin();
        bool   	hasNext();
        AbaxKeyValue<K,V>  next( );

    private:
        AbaxHashMap<K,V> *_mapobj; 

		unsigned long 	_count;
		unsigned long 	_itermax;
		unsigned char   _type; // 0: all;  10: has start;  20: has start and end element
		bool   			_doneBegin;
		long	    	_cursor;
};


template <class K2 > class AbaxHashSetIterator;

/***
  Hash set
***/
template <class K>
class AbaxHashSet 
{

    template <class K2 > friend class AbaxHashSetIterator;

    public: 

        AbaxHashSet(  );
        ~AbaxHashSet() { destroy(); }

        bool addKey( const K& key );
        bool keyExist(  const K& key );
        bool removeKey( const K& key );
        long size( ) const; 
		void  destroy(); 
		const K  *array() const; 
        long arrayLength( ) const; 
		bool isNull( long i ) const; 

		void print() const; 
		void concurrent( bool flag = true );

    private:
        AbaxHashArray<K>  *_xarr; 
		AbaxReadWriteLock  *_lock;

};


/***
  Iterator of hash set
***/
template <class K >
class AbaxHashSetIterator
{
    public: 

        AbaxHashSetIterator( AbaxHashSet<K> *hmap );
        AbaxHashSetIterator( AbaxHashSet<K> *hmap, unsigned long count );

        ~AbaxHashSetIterator();

        void  	begin();
        bool   	hasNext();
        const K& next( );

    private:
        AbaxHashSet<K> *_mapobj; 

		unsigned long 	_count;
		unsigned long 	_itermax;
		unsigned char   _type; // 0: all;  10: has start;  20: has start and end element
		bool   			_doneBegin;
		long	    _cursor;
};



////////////////////////////////// AbaxGraph Ralated Classes /////////////////////////////////////////////////
/***
  A node is represented by a key and value
***/
template <class K, class V>
class AbaxGraphNode
{
    template <class K2,class V2 > friend abaxstream& operator<< (abaxstream &os, const AbaxGraphNode<K2, V2> & pair );
	
	public:
		K key;
		V value;

		static  AbaxGraphNode  NULLVALUE; 
        inline AbaxGraphNode() {}
        inline AbaxGraphNode( const K &k) : key(k) {}
        inline AbaxGraphNode( const K &k, const V &v) : key(k), value(v) {}

        inline int operator< ( const AbaxGraphNode &d2 ) const {
           	return ( key < d2.key );
		}
        inline int operator<= ( const AbaxGraphNode &d2 ) const {
           	return ( key < d2.key );
		}
        inline int operator> ( const AbaxGraphNode &d2 ) const {
           	return ( key > d2.key );
		}
        inline int operator>= ( const AbaxGraphNode &d2 ) const {
           	return ( key >= d2.key );
		}

        inline int lt ( const AbaxGraphNode &d2, const AbaxFormat &kfmt ) const {
			if ( kfmt.len > 0 && K::isString() ) {
				return ( compareString<K>(key, d2.key, kfmt) < 0 ?1:0 );
			} else {
           		return ( key < d2.key );
			}
		}
        inline int le ( const AbaxGraphNode &d2, const AbaxFormat &kfmt ) const {
			if ( kfmt.len > 0 && K::isString() ) {
				return ( compareString<K>(key, d2.key, kfmt) <= 0 ?1:0 );
			} else {
           		return ( key <= d2.key );
			}
		}
        inline int gt ( const AbaxGraphNode &d2, const AbaxFormat &kfmt ) const {
			if ( kfmt.len > 0 && K::isString() ) {
				return ( compareString<K>(key, d2.key, kfmt) > 0 ?1:0 );
			} else {
           		return ( key > d2.key );
			}
		}
        inline int ge ( const AbaxGraphNode &d2, const AbaxFormat &kfmt ) const {
			if ( kfmt.len > 0 && K::isString() ) {
				return ( compareString<K>(key, d2.key, kfmt) >= 0 ?1:0 );
			} else {
           		return ( key >= d2.key );
			}
		}

        inline int operator== ( const AbaxGraphNode &d2 ) const
        {
           	return ( key == d2.key );
        }
        inline int operator!= ( const AbaxGraphNode &d2 ) const
        {
            return ( ! ( key == d2.key ) );
        }
        inline AbaxGraphNode&  operator= ( const AbaxGraphNode &d3 )
        {
            key = d3.key;
            value = d3.value;
            return *this;
        }

        inline void setValue( const V &newvalue ) {
            value = newvalue;
        }

		inline void valueDestroy( AbaxDestroyAction action ) {
			value.destroy( action );
		}

        inline long hashCode() const { return key.hashCode(); }
};


/***
  A link (edge) is represented by two keys (key1, key2), a property (value) associated with the link,
  and a weight associated with the property(value).
***/
template <class K, class EV, class EW>
class AbaxGraphLink
{
    template <class K2,class V2, class W2> friend abaxstream& operator<< (abaxstream &os, const AbaxGraphLink<K2, V2, W2> & pair );

    public:

        K 	key1;    // start key
        K 	key2;    // end key
        EV 	value;   // property of the link (edge)
        EW 	weight;  // weight of the property

		static  AbaxGraphLink  NULLVALUE; 
		static const long   HALFMAX = LONG_MAX >> 1;

        inline AbaxGraphLink() {}
        inline AbaxGraphLink( const K &k1 ) : key1(k1), key2(k1) {}
        inline AbaxGraphLink( const K &k1, const K &k2) : key1(k1), key2(k2) {}
        inline AbaxGraphLink( const K &k1, const K &k2, const EV &v) : key1(k1), key2(k2), value(v) {}
        inline AbaxGraphLink( const K &k1, const K &k2, const EV &v, const EW &w) 
		    : key1(k1), key2(k2), value(v), weight(w) {}

        inline int operator< (const AbaxGraphLink &d2 ) const
        {
           	return ( key1 < d2.key1 || ( key1==d2.key1 && key2<d2.key2 ) );
        }
        inline int operator<= (const AbaxGraphLink &d2 ) const
        {
           	return ( key1 < d2.key1 || ( key1==d2.key1 && key2<=d2.key2 ) );
        }
        inline int operator> ( const AbaxGraphLink &d2 ) const
        {
           	return ( key1 > d2.key1 || ( key1==d2.key1 && key2>d2.key2 ) );
        }
        inline int operator>= ( const AbaxGraphLink &d2 ) const
        {
           	return ( key1 > d2.key1 || ( key1==d2.key1 && key2>=d2.key2 ) );
        }


        int lt (const AbaxGraphLink &d2, const AbaxFormat &fmt ) const
        {
			int rc1, rc2;
			if ( fmt.len>0 && K::isString() ) {
				// rc1 = compareString<AbaxString>( key1, d2.key1, fmt); 
				rc1 = compareString<K>( key1, d2.key1, fmt); 
				if ( rc1 < 0 ) { return 1; }
				else if ( 0 == rc1 ) {
					rc2 = compareString<K>( key2, d2.key2, fmt); 
					return ( (rc2<0) ?  1 : 0 );
				} else {
					return 0;
				}
			} else {
           		return ( key1 < d2.key1 || ( key1==d2.key1 && key2<d2.key2 ) );
			}
        }

        int le (const AbaxGraphLink &d2, const AbaxFormat &fmt ) const
        {
			int rc1, rc2;
			if ( fmt.len>0 && K::isString() ) {
				rc1 = compareString<AbaxString>( key1, d2.key1, fmt); 
				if ( rc1 < 0 ) { return 1; }
				else if ( 0 == rc1 ) {
					rc2 = compareString<AbaxString>( key2, d2.key2, fmt); 
					return ( (rc2<=0) ?  1 : 0 );
				} else {
					return 0;
				}
			} else {
           		return ( key1 < d2.key1 || ( key1==d2.key1 && key2<=d2.key2 ) );
			}
        }

        int gt (const AbaxGraphLink &d2, const AbaxFormat &fmt ) const
        {
			int rc1, rc2;
			if ( fmt.len>0 && K::isString() ) {
				rc1 = compareString<K>( key1, d2.key1, fmt); 
				if ( rc1 > 0 ) { return 1; }
				else if ( 0 == rc1 ) {
					rc2 = compareString<K>( key2, d2.key2, fmt); 
					return ( (rc2>0) ?  1 : 0 );
				} else {
					return 0;
				}
			} else {
           		return ( key1 > d2.key1 || ( key1==d2.key1 && key2>d2.key2 ) );
			}
        }

        int ge (const AbaxGraphLink &d2, const AbaxFormat &fmt ) const
        {
			int rc1, rc2;
			if ( fmt.len>0 && K::isString() ) {
				rc1 = compareString<K>( key1, d2.key1, fmt); 
				if ( rc1 > 0 ) { return 1; }
				else if ( 0 == rc1 ) {
					rc2 = compareString<K>( key2, d2.key2, fmt); 
					return ( (rc2>=0) ?  1 : 0 );
				} else {
					return 0;
				}
			} else {
           		return ( key1 > d2.key1 || ( key1==d2.key1 && key2>=d2.key2 ) );
			}
        }

        inline int operator== ( const AbaxGraphLink &d2 ) const
        {
           	return ( key1 == d2.key1 && key2==d2.key2 );
        }
        inline int operator!= ( const AbaxGraphLink &d2 ) const
        {
           	return ( ! ( key1 == d2.key1 && key2==d2.key2 ) );
        }
        inline int isKey1Null() const
        {
           	return ( key1 == K::NULLVALUE );
        }
        inline int isKey2Null() const
        {
           	return ( key2 == K::NULLVALUE );
        }

        int compare( const AbaxGraphLink &d2, const AbaxFormat &fmt ) const
        {
            if ( lt(d2, fmt) ) {
                return -1;
            } else if ( gt( d2, fmt) ) {
                return 1;
            } else {
                return 0;
            }
        }

        AbaxGraphLink&  operator= ( const AbaxGraphLink &d2 )
        {
            key1 = d2.key1;
            key2 = d2.key2;
            value = d2.value;
            weight = d2.weight;
            return *this;
        }

        inline void setValue( const EV &newvalue ) {
            value = newvalue;
        }

		void valueDestroy( AbaxDestroyAction action ) {
			value.destroy( action );
		}

        long hashCode() const { 
			long h1 = key1.hashCode(); 
			if ( isKey2Null() ) return h1;

			long h2 = key2.hashCode(); 
			if ( isKey1Null() ) return  h2;

			if ( h1 < HALFMAX ) {
				return h1+ (h2>>1);
			} else {
				return (h1 >> 1) + (h2 >> 2);
			}
		}
};


// K-V  node key-value   EV: K1-K2 edge value  EW: edge weight
template <class K, class V, class EV, class EW>
class AbaxGraph
{
	public:
		AbaxGraph( AbaxGraphType type=ABAX_UNDIRECTED );
		~AbaxGraph();
		void destroy(); 
		bool addNode( const K& k, const V &v );
		bool addNode( const AbaxGraphNode<K,V> &node ); 

		bool removeNode( const K& k );
		bool removeNode( const AbaxGraphNode<K,V> &node ); 

		bool addLink( const K& k1, const K& k2, const EV &ev,  const EW &ew );

		bool removeLink( const K& k1, const K& k2, bool dolock = true );
		bool removeLink( const AbaxGraphLink<K, EV, EW> & link );

		// long neighbors( const K& k, AbaxVector<K> &vec, AbaxLinkType type=ABAX_DOUBLELINK );
		long neighbors( const K& k, AbaxVector<K> &vec, AbaxLinkType type, bool dolock=true );
		long neighbors( const AbaxGraphNode<K,V>& node, AbaxVector<K> &vec, AbaxLinkType type=ABAX_DOUBLELINK );

		long outNeighbors( const K& k, AbaxVector<K> &vec );
		long outNeighbors( const AbaxGraphNode<K,V>& node, AbaxVector<K> &vec );

		long inNeighbors( const K& k, AbaxVector<K> &vec );
		long inNeighbors( const AbaxGraphNode<K,V>& node, AbaxVector<K> &vec );

		long  minSpanTreePrim( AbaxHashSet< AbaxKeyKeyPair<K,EW> > &links, EW &cost );
		long  numberOfNodes() const;
		long  numberOfLinks() const;
		void  concurrent( bool flag = true );
		bool  isAdjacent( const K& k1, const K& k2 );

	protected:
        AbaxFlatSet< AbaxGraphNode<K,V> >   *_node; 
        AbaxFlatSet<AbaxGraphLink<K,EV,EW> >  *_link; 
        AbaxFlatSet<AbaxGraphLink<K,EV,EW> >  *_olink; 
        AbaxFlatSet<AbaxGraphLink<K,EV,EW> >  *_ilink; 

		AbaxGraphType type;  // enum AbaxGraphType { ABAX_UNDIRECTED=0, ABAX_DIRECTED=1 };
		AbaxReadWriteLock  *_lock;
};


template <class Pair> class AbaxHeapData;
template <class Pair> class AbaxHeapSort;

////////////////////////////////// AbaxPriorityQueue //////////////////////////////////////////////////
template <class K, class W>
class AbaxPriorityQueue
{
	public:
		AbaxPriorityQueue( unsigned long capacity=256, AbaxQueueType type=ABAX_MINQUEUE );
		~AbaxPriorityQueue();
		void destroy();
		bool push( const K &key, W weight);
		bool peek( K &key, W &weight );
		bool pop( K &key, W &weight );
		bool popAndAddKey( K &popKey, W &popWeight, const K &newKey, W newWeight);
		abaxint size() const;
		void concurrent( bool flag = true );

	protected:
		AbaxQueueType  _qtype;
		AbaxHeapData<AbaxPair<W,K> > *_heapData;
		unsigned long _capacity;
		AbaxHeapSort<AbaxPair<W,K> >  *_heapSort;
		AbaxFormat  fmt;

		abaxint capacity() const ;
		void resize();
		void shrink();
		AbaxReadWriteLock  *_lock;
};



/////////////////// AbaxQueue ///////////////////////
// circular queue   _first ...  _last
// circular queue   ... _last         _first ...
// If it becomes too small, resize to larger array
template <class Pair>
class AbaxQueue
{
	public:

		AbaxQueue( int initSize = 256 );
		~AbaxQueue();

		void push( const Pair &pair );
		Pair pop();
		inline const Pair &front();
		inline const Pair &back();
		inline  abaxint size() const { return _elements; }
		inline  abaxint capacity() const { return _arrlen; }
		void 	destroy();
		void 	print();
		void 	reAlloc();
		void 	reAllocShrink();
		void    concurrent( bool flag = true );

	protected:

		Pair   		*_arr;
		abaxint  	_arrlen;
		Pair   		*_newarr;
		abaxint  	_newarrlen;

		abaxint  	_first;
		abaxint  	_last;
		abaxint  	_elements;
		AbaxReadWriteLock  *_lock;

		static const int _GEO  = 2;	 
};

// ctor
template <class Pair> 
AbaxQueue<Pair>::AbaxQueue( int initSize )
{
	_arr = new Pair[initSize];
	_arrlen = initSize;
	_first = 0;
	_last = -1;
	_elements = 0;
	_lock = NULL;
}

// dtor
template <class Pair> 
void AbaxQueue<Pair>::destroy( )
{
	delete [] _arr; 
	_arrlen = 0;
	_elements = 0;
	_first = 0;
	_last = -1;
}

// dtor
template <class Pair> 
AbaxQueue<Pair>::~AbaxQueue( )
{
	destroy();
	if ( _lock ) {
		delete _lock;
		_lock = NULL;
	}
}


template <class Pair> 
void AbaxQueue<Pair>::reAlloc()
{
	abaxint i;
	_newarrlen  = _GEO*_arrlen; 

	_newarr = new Pair[_newarrlen];
	abaxint pos = 0;
	if ( _first <= _last ) {
		for ( i = _first; i <= _last; ++i) {
			_newarr[pos++] = _arr[i];
		}
	} else {
		for ( i = _first; i < _arrlen; ++i) {
			_newarr[pos++] = _arr[i];
		}
		for ( i = 0; i <= _last; ++i) {
			_newarr[pos++] = _arr[i];
		}
	}

	delete [] _arr;
	_arr = _newarr;
	_arrlen = _newarrlen;
	_first = 0;
	_last = pos-1;
}

template <class Pair> 
void AbaxQueue<Pair>::reAllocShrink()
{
	abaxint i;

	_newarrlen  = _arrlen/_GEO; 
	_newarr = new Pair[_newarrlen];

	abaxint pos = 0;
	if ( _first <= _last ) {
		for ( i = _first; i <= _last; ++i) {
			_newarr[pos++] = _arr[i];
		}
	} else {
		for ( i = _first; i < _arrlen; ++i) {
			_newarr[pos++] = _arr[i];
		}
		for ( i = 0; i <= _last; ++i) {
			_newarr[pos++] = _arr[i];
		}
	}

	delete [] _arr;
	_arr = _newarr;
	_arrlen = _newarrlen;
	_first = 0;
	_last = pos-1;
}


template <class Pair> 
void AbaxQueue<Pair>::push( const Pair &newpair )
{
	AbaxReadWriteMutex mutex( _lock, AbaxReadWriteMutex::WRITE_LOCK );

	if ( _elements == _arrlen-1 ) { reAlloc(); }

	++ _last;
	_arr[_last] = newpair;
	++ _elements;
}

// front: out end  (pop end, dequeue end)
template <class Pair> 
const Pair &AbaxQueue<Pair>::front()
{
	AbaxReadWriteMutex mutex( _lock, AbaxReadWriteMutex::READ_LOCK );
	if ( _elements < 1 ) return Pair::NULLVALUE;
	return _arr[ _first ];
}

// back: add end (enqueue end)
template <class Pair> 
const Pair &AbaxQueue<Pair>::back()
{
	AbaxReadWriteMutex mutex( _lock, AbaxReadWriteMutex::READ_LOCK );
	if ( _elements < 1 ) return Pair::NULLVALUE;
	return _arr[ _last ];
}


template <class Pair> 
Pair AbaxQueue<Pair>::pop()
{
	AbaxReadWriteMutex mutex( _lock, AbaxReadWriteMutex::WRITE_LOCK );
	if ( _elements < 1 ) return Pair::NULLVALUE;

	abaxint old = _first;
	if ( _arrlen >= 64 ) {
    	long loadfactor  = 100 * (long)_elements / _arrlen;
    	if (  loadfactor < 20 ) {
    		reAllocShrink();
			old = 0;
    	}
	} 

	-- _elements;
	++_first;
	if ( _first == _arrlen ) _first = 0; 
	return _arr[ old ];
}


template <class Pair> 
void AbaxQueue<Pair>::print()
{
	char buf[16];
	abaxint i;

	abaxcout << "c3003 AbaxQueue: _arrlen=" << _arrlen << " _elements=" << _elements << " _first=" << _first << " _last=" << _last;
	abaxcout << abaxendl;
	if ( _first <= _last ) {
		for ( i = _first; i  <= _last; ++i) {
			sprintf( buf, "%08d", i );
			abaxcout << buf << ": " << _arr[i] << abaxendl;
		}
	} else {
		for ( i = _first; i < _arrlen; ++i ) {
			sprintf( buf, "%08d", i );
			abaxcout << buf << ": " << _arr[i] << abaxendl;
		}
		for ( i = 0; i <= _last; ++i ) {
			sprintf( buf, "%08d", i );
			abaxcout << buf << ": " << _arr[i] << abaxendl;
		}
	}

	abaxcout << abaxendl;
}


template <class Pair>
void AbaxQueue<Pair>::concurrent( bool flag )
{
    if ( flag ) {
        if ( ! _lock ) {
            _lock = new AbaxReadWriteLock();
        }
    } else {
        if ( _lock ) {
            delete _lock;
            _lock = NULL;
        }
    }
}


/////////////////// AbaxStack ///////////////////////
// circular queue   0 ...  _last--> (push pop)
template <class Pair>
class AbaxStack
{
	public:

		AbaxStack( int initSize = 256 );
		~AbaxStack();

		void 	push( const Pair &pair );
		Pair 	pop();
		inline const Pair &top();
		inline const Pair &bottom();
		inline  abaxint size() const { return _last+1; }
		inline  abaxint capacity() const { return _arrlen; }
		void 	destroy();
		void 	print();
		void 	reAlloc();
		void 	reAllocShrink();
		void    concurrent( bool flag = true );

	protected:

		Pair   		*_arr;
		abaxint  	_arrlen;
		abaxint  	_last;
		static const int _GEO  = 2;
		AbaxReadWriteLock  *_lock;
};

// ctor
template <class Pair> 
AbaxStack<Pair>::AbaxStack( int initSize )
{
	_arr = new Pair[initSize];
	_arrlen = initSize;
	_last = -1;
	_lock = NULL;
}

// dtor
template <class Pair> 
void AbaxStack<Pair>::destroy( )
{
	delete [] _arr; 
	_arrlen = 0;
	_last = -1;
}

// dtor
template <class Pair> 
AbaxStack<Pair>::~AbaxStack( )
{
	destroy();
	if ( _lock ) {
		delete _lock;
		_lock = NULL;
	}
}


template <class Pair> 
void AbaxStack<Pair>::reAlloc()
{
	abaxint i;
	abaxint newarrlen  = _GEO*_arrlen; 
	Pair *newarr;

	newarr = new Pair[newarrlen];
	for ( i = 0; i <= _last; ++i) {
		newarr[i] = _arr[i];
	}
	delete [] _arr;
	_arr = newarr;
	_arrlen = newarrlen;
}

template <class Pair> 
void AbaxStack<Pair>::reAllocShrink()
{
	abaxint i;
	Pair *newarr;

	abaxint newarrlen  = _arrlen/_GEO; 
	newarr = new Pair[newarrlen];
	for ( i = 0; i <= _last; ++i) {
		newarr[i] = _arr[i];
	}

	delete [] _arr;
	_arr = newarr;
	_arrlen = newarrlen;
}


template <class Pair> 
void AbaxStack<Pair>::push( const Pair &newpair )
{
	AbaxReadWriteMutex mutex( _lock, AbaxReadWriteMutex::WRITE_LOCK );
	if ( _last == _arrlen-1 ) { reAlloc(); }

	++ _last;
	_arr[_last] = newpair;
}

// front: out end  (pop end, dequeue end)
template <class Pair> 
const Pair &AbaxStack<Pair>::bottom()
{
	if ( _last < 0 ) return Pair::NULLVALUE;
	return _arr[ 0 ];
}

// back: add end (enqueue end)
template <class Pair> 
const Pair &AbaxStack<Pair>::top()
{
	if ( _last >= _arrlen ) return Pair::NULLVALUE;
	return _arr[ _last ];
}


template <class Pair> 
Pair AbaxStack<Pair>::pop()
{
	AbaxReadWriteMutex mutex( _lock, AbaxReadWriteMutex::WRITE_LOCK );

	if ( _last < 0 ) return Pair::NULLVALUE;

	if ( _arrlen >= 64 ) {
    	long loadfactor  = (100 * _last) / _arrlen;
    	if (  loadfactor < 20 ) {
    		reAllocShrink();
    	}
	} 

	return _arr[ _last-- ];
}


template <class Pair> 
void AbaxStack<Pair>::print()
{
	char buf[16];
	abaxint i;

	abaxcout << "c3003 AbaxStack: _arrlen=" << _arrlen << " _last=" << _last;
	abaxcout << abaxendl;
	for ( i = 0; i  <= _last; ++i) {
		sprintf( buf, "%08d", i );
		abaxcout << buf << ": " << _arr[i] << abaxendl;
	}

	abaxcout << abaxendl;
}

template <class Pair>
void AbaxStack<Pair>::concurrent( bool flag )
{
    if ( flag ) {
        if ( ! _lock ) {
            _lock = new AbaxReadWriteLock();
        }
    } else {
        if ( _lock ) {
            delete _lock;
            _lock = NULL;
        }
    }
}



template <class DataType2 >
abaxstream& operator<< (abaxstream &os, const AbaxNumeric<DataType2> & d );

template <class KType2, class VType2>
abaxstream& operator<< ( abaxstream &os, const AbaxPair<KType2,VType2> & pair );

template <class KType2>
abaxstream& operator<< ( abaxstream &os, const AbaxKeyPair<KType2> & pair );


template <class KType, class VType >
abaxstream& operator<< ( abaxstream &os, const AbaxKeyKeyPair<KType,VType> & pair );

abaxstream& operator<< (abaxstream &os, const AbaxString &str );
abaxstream& operator<< (abaxstream &os, const AbaxNumeric<int> & d );
abaxstream& operator<< (abaxstream &os, const AbaxBuffer &p );


#endif
