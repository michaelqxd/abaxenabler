////////////////////////////////////////////////////////////////////////
//
//  Exeray Inc 
//
//  Sample program of BigData Enabler
//
///////////////////////////////////////////////////////////////////////
#include <stdio.h>
#include <abaxenabler.h>

int main( int argc, char *argv[] )
{

    AbaxMap<AbaxString, AbaxInt>  abaxmap; 

	// Method concurrent( true ) makes the AbaxMap object thread safe
	// abaxmap.concurrent( true );
	// abaxmap.concurrent( false );

    AbaxString k;
    AbaxInt    v;

	// insert key-value pairs into the container
	k = "hello";
    v = 30;
    abaxmap.addKeyValue( k, v); 
	
	k = "world";
    v = 34;
    abaxmap.addKeyValue( k, v); 

	// Read value into v
    abaxmap.getValue( k, v); 

	// Update the value of key
    v = 40;
    abaxmap.setValue( k, v); 


	// Remove the key-value pair frome the container
	k = "door";
    abaxmap.removeKey( k ); 


	// Check if a key-value pair exists in the container
    bool rc = abaxmap.keyExist( k );


	// Iterators read key-value pairs from the container
	// Forward iterator: keys in ascending order
    AbaxMapIterator<AbaxString, AbaxInt> iter( &abaxmap );
    while ( iter.hasNext() ) {
        AbaxKeyValue<AbaxString, AbaxInt> pair = iter.next();
        abaxcout << "key=" << pair.key << " value=" << pair.value << abaxendl;
    }
   
	// Reverse iterator: keys in descending order
    AbaxMapReverseIterator<AbaxString, AbaxInt> iter2( &abaxmap );
    while ( iter2.hasNext() ) {
        AbaxKeyValue<AbaxString, AbaxInt> pair = iter2.next();
        abaxcout << "key=" << pair.key << " value=" << pair.value << abaxendl;
    }

	return 0;
}

